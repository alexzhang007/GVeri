#ifndef __GVERI_XML_H__
#define __GVERI_XML_H__
#include "gveri-db.h"
#define FAILURE 1

typedef enum{
	TOPMODULE,
	ENDMODULE,
	SUBMODULE
}LineType;
GVeriScope* gveri_xml_parse(char* line, LineType* lineType);
int gveri_xml_load(GVeriScope** proot);
#endif

