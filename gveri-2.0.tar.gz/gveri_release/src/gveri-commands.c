#include <gtk/gtk.h>
#include <unistd.h>
#include "gveri-commands.h"
#include "gveri-lst.h"

#define CMD_LEN  3000
extern GVeriScope* root;
extern GVeriScope* current_scope;
extern GVeriList* header;
extern gboolean verbose_flag;
int child_num=0;
void		_gveri_cmd_parent_module		(GtkAction   *action, GVeriWindow *window){
		if(verbose_flag)
			printf ("ALZ : enter parent module\n");		
		GVeriScope* parent = get_parent(current_scope);
		if(verbose_flag)
			printf ("ALZ : file%s and the parent file %s\n", current_scope->fileName, parent->fileName);		

		if(parent!=NULL) {
			window->current_doc = gveri_load_file(parent->fileName);		
			gtk_text_buffer_set_text(GTK_TEXT_BUFFER(window->buffer), window->current_doc->str, -1);	
		}else {
			if(verbose_flag)
				printf ("ALZ : no parent or top level\n");		
		}
}
void		_gveri_cmd_file_new			    (GtkAction   *action, GVeriWindow *window){}
void		_gveri_cmd_file_open			(GtkAction   *action, GVeriWindow *window) {} 
void		_gveri_cmd_file_save			(GtkAction   *action, GVeriWindow *window) {}
void		_gveri_cmd_file_save_as			(GtkAction   *action, GVeriWindow *window) {}
void		_gveri_cmd_edit_preferences		(GtkAction   *action, GVeriWindow *window) {}
void		_gveri_cmd_help_contents		(GtkAction   *action, GVeriWindow *window) {}
void		_gveri_cmd_help_about			(GtkAction   *action, GVeriWindow *window){}

static void store_filename (GtkWidget *widget, GVeriWindow* user_data) {
        GtkWidget *file_selector = GTK_WIDGET (user_data->file_selection);
     //   const gchar *selected_filename;
     
        user_data->design_file = gtk_file_selection_get_filename (GTK_FILE_SELECTION (file_selector));
		if(verbose_flag)
        	printf ("Selected filename: %s\n", user_data->design_file);
		gveri_lst_load(&header, user_data->design_file);
		GVeriList* p = header;
		while(p) {
			add_to_list(user_data->listView, p->recentFileName);		
			p=p->next;
		}

}


void 		_gveri_cmd_load_design			(GtkAction   *action, GVeriWindow *window){
	window->file_selection = gtk_file_selection_new ("Load Design File");
	gtk_file_selection_set_filename(GTK_FILE_SELECTION(window->file_selection),"*.lst");
	gtk_widget_show(window->file_selection);
	g_signal_connect (GTK_FILE_SELECTION (window->file_selection)->ok_button,"clicked", G_CALLBACK (store_filename),window);
	 /* Ensure that the dialog box is destroyed when the user clicks a button. */
    g_signal_connect_swapped (GTK_FILE_SELECTION (window->file_selection)->ok_button,"clicked", G_CALLBACK (gtk_widget_destroy), window->file_selection);
    g_signal_connect_swapped (GTK_FILE_SELECTION (window->file_selection)->cancel_button,  "clicked",G_CALLBACK (gtk_widget_destroy),window->file_selection);

}
void		_gveri_cmd_quit					(GtkAction   *action, GVeriWindow *window){}
void		_gveri_cmd_lock_content			(GtkAction   *action, GVeriWindow *window){}
void		_gveri_cmd_unlock_content		(GtkAction   *action, GVeriWindow *window){}
gboolean gveri_gtkwave(gpointer cmd){

		system((char*)cmd);
		return TRUE;
}
void		_gveri_cmd_view_waveform		(GtkAction   *action, GVeriWindow *window){
	char* cmd=(char*)malloc(sizeof(char)*CMD_LEN);
	char directory[80];
	memset(cmd, '\0', CMD_LEN);
	strcat(cmd , "/home/alzhang/gtkwave/bin/gtkwave ");
	getcwd(directory, sizeof(directory));
	strcat(directory,"/");
	strcat(directory,"risc8.vcd");
	strcat(cmd, directory);
	//gtk_idle_add(gveri_gtkwave, cmd);
	system(cmd);
			
}
void		_gveri_cmd_view_all_signals		(GtkAction   *action, GVeriWindow *window){}
void		_gveri_cmd_child_module			(GtkAction   *action, GVeriWindow *window){
		GVeriScope* child = get_child(current_scope, &child_num);
		if(verbose_flag)
			printf("ALZ:: %s has child %d\n", current_scope->scopeName, child_num);
		if(child!=NULL) {
			window->current_doc = gveri_load_file(child->fileName);		
			gtk_text_buffer_set_text(GTK_TEXT_BUFFER(window->buffer), window->current_doc->str, -1);	


		}else {
			if(verbose_flag)
				printf ("ALZ : no parent or top level\n");		
		}

		
}
void		_gveri_cmd_up					(GtkAction   *action, GVeriWindow *window){
	GVeriScope* up;
	if(child_num>1) {
		up=current_scope->prev;
		if(up) {
			window->current_doc = gveri_load_file(up->fileName);		
			current_scope = up;
			gtk_text_buffer_set_text(GTK_TEXT_BUFFER(window->buffer), window->current_doc->str, -1);	
		}
	}		
}
void		_gveri_cmd_down					(GtkAction   *action, GVeriWindow *window){
	GVeriScope* down;
	if(child_num>1) {
		down=current_scope->next;
		if(down) {
			window->current_doc = gveri_load_file(down->fileName);		
			current_scope = down;
			gtk_text_buffer_set_text(GTK_TEXT_BUFFER(window->buffer), window->current_doc->str, -1);	
		}
	}		
			
}
void		_gveri_cmd_backward_history		(GtkAction   *action, GVeriWindow *window){
	if(window->current_file->prev	!= NULL	) {
		window->current_file = window->current_file->prev;
		gtk_text_buffer_set_text(GTK_TEXT_BUFFER(window->buffer), window->current_file->context, -1);		
		gtk_label_set_text(GTK_LABEL(window->fileTitle), window->current_file->fileFullPath);

	}
}
void		_gveri_cmd_forward_history		(GtkAction   *action, GVeriWindow *window){
	if(window->current_file->next	!= NULL	) {
		window->current_file = window->current_file->next;
		gtk_text_buffer_set_text(GTK_TEXT_BUFFER(window->buffer), window->current_file->context, -1);		
		gtk_label_set_text(GTK_LABEL(window->fileTitle), window->current_file->fileFullPath);
	}
		
}
void		_gveri_cmd_simulation			(GtkAction   *action, GVeriWindow *window){
		char directory[80];
		char* cmd=(char*)malloc(sizeof(char)*CMD_LEN);
		memset(cmd, '\0', CMD_LEN);
		strcat(cmd , "/home/alzhang/usr/bin/iverilog ");
		GVeriList *p = gveri_list_get_test(header,"test.v");
		GVeriList *q;
		if(p){
			if(verbose_flag)
				printf("Find the design enterance file\n");
			strcat(cmd, p->fileFullPath);
			strcat(cmd ," ");
			//append the next file to cmd
			q=p->next;
			while(q) {
				strcat(cmd, q->fileFullPath);
				strcat(cmd ," ");
				q = q->next;		
			}
			q = p->prev;
			while(q) {
				strcat(cmd, q->fileFullPath);
				strcat(cmd ," ");
				q = q->prev;		
			}

		}
		//execute the command
		if(verbose_flag)
			printf("The command is %s\n", cmd);
		system(cmd);
		getcwd(directory, sizeof(directory));
		if(verbose_flag)
			printf("The current directory is %s\n", directory);
		strcat(directory,"/");
		strcat(directory,"a.out");
		
		memset(cmd, '\0', CMD_LEN);
		strcat(cmd, "/home/alzhang/usr/bin/vvp ");
		strcat(cmd, directory);
		system(cmd);
		
}
void		_gveri_cmd_find_module			(GtkAction   *action, GVeriWindow *window){}
void		_gveri_cmd_find_file			(GtkAction   *action, GVeriWindow *window){}
void		_gveri_cmd_find_string			(GtkAction   *action, GVeriWindow *window){}

