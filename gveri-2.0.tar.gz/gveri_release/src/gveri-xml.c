#include "gveri-xml.h"
#include "gveri.h"
//GVeriScope* root=NULL;

GVeriScope* gveri_xml_parse(char* line, LineType* lineType){
	//printf("ALZ : %s",line);		
	GVeriScope* pGveri;
	char* pch;
	if(pch=strchr(line, '\\')){
		*lineType=SUBMODULE;
	}else if(pch=strstr(line,"</module")){
		*lineType=ENDMODULE;
	}else{
		*lineType=TOPMODULE;
	}
	pGveri=(GVeriScope*)malloc(sizeof(GVeriScope));
	init_gveri_scope(&pGveri);
	switch(*lineType) {
		case TOPMODULE:
		case SUBMODULE:
			pch=strtok(line, " \"<>\\=");
			while(pch!=NULL) {
				if(verbose_flag)
					printf("%s\t",pch);
				if(strcmp(pch, "name")==0){
					pch=strtok(NULL, " \"<>\\=");
					strcpy(pGveri->scopeName, pch);
				}else if(strcmp(pch,"instance")==0){
					pch=strtok(NULL, " \"<>\\=");
					strcpy(pGveri->scopeInstName, pch);
				}else if(strcmp(pch,"filename")==0){
					pch=strtok(NULL, " \"<>\\=");
					strcpy(pGveri->fileName, pch);
				}
				pch=strtok(NULL, " \"<>\\=");
			}
		break;
		case ENDMODULE:
			free(pGveri);
			pGveri=NULL;
		break;
	}
	//printf("ALZ : ModuleName=%s, InstanceName=%s, fileName=%s\n", pGveri->scopeName, pGveri->scopeInstName, pGveri->fileName);
	return pGveri;
}
int gveri_xml_load(GVeriScope** proot){
	GVeriScope* root=(*proot);
	FILE* fp=fopen(GVERI_DATADIR "ui/design.xml","r");
	char* line=NULL;
	size_t len=0;
	ssize_t read;
	GVeriScope* child;
	GVeriScope* parent;
	LineType lineType;
	int firstChild=0;//The variable can be moved if the datastruct is Good
	if(fp==NULL){
		if(verbose_flag)
			printf("ALZ : Cannot open the file\n");
		//exit(FAILURE);
		return 0;
	}
	while((read=getline(&line, &len, fp))!=-1){
		if(verbose_flag)
			printf("%s",line);		
		child = gveri_xml_parse(line,&lineType);
		if(root==NULL){
			root = child;		
			parent=root;
			firstChild=1;
		}else{
			if(lineType==SUBMODULE){
				if(firstChild) {
					parent->child=child;		
					child->parent  = parent;//alzhang : add the parent node bug: that the parent is changed
					parent  = parent->child;
					if(verbose_flag)
						printf("***: the filename =%s\n", parent->fileName);
					firstChild=0;
				}else {
					parent->next = child;	
					child->prev = parent; //add the prev function
					child->parent = parent->parent;//alzhang : add the parent node
					parent=parent->next;
				}
			}else if (lineType == TOPMODULE) {
				parent=find_gveri_scope(root, child->scopeName);		
				if(verbose_flag)
					printf("ALZ : Find Parent:%s\n", parent->scopeName);
				firstChild=1;
			}else if (lineType == ENDMODULE ) {
				continue;		
			}
		}
	}
	if(verbose_flag)
		printf("ALZ :: Print the GVeriScope List:\n");
	if(verbose_flag)
		print_gveri_scope(root);
	if(verbose_flag)
		printf("ALZ :: Leaving Print the GVeriScope List\n");
	*proot=root;
	if(line) 
		free(line);
	fclose(fp);
	return 1;
}
