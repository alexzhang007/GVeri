#ifndef __GVERI_LST_H__
#define __GVERI_LST_H__
#include "gveri-db.h"

GVeriList* gveri_lst_parse(char* line);
void gveri_lst_load(GVeriList** pheader, const char* filename);

#endif
