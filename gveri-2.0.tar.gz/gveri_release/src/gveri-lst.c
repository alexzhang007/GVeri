#include "gveri-lst.h"
#include "gveri.h"
char* strsub(char* start){
	int len=strlen(start);
	char *p=(char*)malloc(sizeof(char)*len);
	memset(p, '\0', len+1);
	memcpy(p, start, len -1); //because there is \n\0 in the orignial str
	return p;
}
GVeriList* gveri_lst_parse(char* line){
	GVeriList* p=(GVeriList*)malloc(sizeof(GVeriList));
	init_gveri_list(&p);
	char* pch=strrchr(line,'/');
	if(pch) {
		//strcpy(p->recentFileName,strsub(pch+1));
		memcpy(p->recentFileName,pch+1,strlen(pch+1)); //because there is \n\0 in the orignial str
		strcpy(p->fileFullPath, line);
	}else {
		if(verbose_flag)
			printf ("ALZ: ERROR in the content:%s\n", line);
		return NULL;
	}
	if(verbose_flag)
		printf("Parser:FileName %s, FUll path:%s\n",pch+1, line);
	return p;
}
void delete_the_enter(char* line) {
	char* p=line;
	while((*p)!='\n') {
		p++;		
	}
	*p=*(p+1);
}
void gveri_lst_load(GVeriList** pheader, const char* filename){
	GVeriList* header = (*pheader);
	FILE *fp=fopen(filename, "r");
	char* line=NULL;
	char* line_without_enter;
	size_t len=0;
	ssize_t read;
	GVeriList* p, *last;

	if(fp==NULL) {
		if(verbose_flag)
			printf("ALZ : Cannot open the lst file: %s\n", filename);
		exit(1);
	}
	while((read=getline(&line, &len, fp))!=-1) {
		if(verbose_flag)
			printf ("File %s\n", line);
		if(line[0]=='#') continue;
		delete_the_enter(line);
		p = gveri_lst_parse(line);
		if(p) {
			if(header==NULL) {
				header = p;
				last=p;
			}else {
				last->next=p;
				p->prev = last;
				last=p;
			}
		}
	}
	print_gveri_list(header);
	*pheader = header;
	
}
