#include "gveri-relation.h"
void init_connect(Connect** connect){
	(*connect)->sub_sig_name=(char*)malloc(sizeof(char)*VARI_NAME_LEN);
	memset((*connect)->sub_sig_name, '\0', VARI_NAME_LEN);
	(*connect)->par_sig_name=(char*)malloc(sizeof(char)*VARI_NAME_LEN);
	memset((*connect)->par_sig_name, '\0', VARI_NAME_LEN);
	(*connect)->sub_gcon_par = GIMPLICIT;
	(*connect)->next = NULL;
}
void init_connection(Connection** connection) {
	(*connection)->file_name = (char*)malloc(sizeof(char)*FILE_NAME_LEN);
	memset((*connection)->file_name, '\0', FILE_NAME_LEN);
	(*connection)->sub_scope_name=(char*)malloc(sizeof(char)*VARI_NAME_LEN);
	memset((*connection)->sub_scope_name, '\0', VARI_NAME_LEN);
	(*connection)->par_scope_name=(char*)malloc(sizeof(char)*VARI_NAME_LEN);
	memset((*connection)->par_scope_name, '\0', VARI_NAME_LEN);
	(*connection)->head_signal_connect = NULL;
}

void init_relation(Relation** relation){
	(*relation)->signal_name = (char*)malloc(sizeof(char)*VARI_NAME_LEN);
	memset((*relation)->signal_name, '\0', VARI_NAME_LEN);
	(*relation)->module_name =  (char*)malloc(sizeof(char)*VARI_NAME_LEN);
	memset((*relation)->module_name, '\0', VARI_NAME_LEN);
	(*relation)->relations=NULL;
	(*relation)->next=NULL;
}
void init_extconnect(ExtConnect** ext_connect){
	(*ext_connect)->inst_module_name = (char*)malloc(sizeof(char)*VARI_NAME_LEN);
	memset((*ext_connect)->inst_module_name, '\0', VARI_NAME_LEN);
	(*ext_connect)->signal_name=(char*)malloc(sizeof(char)*VARI_NAME_LEN);
	memset((*ext_connect)->signal_name, '\0', VARI_NAME_LEN);
}
void init_grnode(GRNode** grnode){
	(*grnode)->next = NULL;		
}

void print_grnode(GRNode* node){
	if(node->type == GDRIVER) {
		printf ("Driver: Line %d \n", node->node.line_num);
	}else if (node->type==GLOADER) {
		printf ("Loader: Line %d \n", node->node.line_num);		
	}else {
		printf ("Cross Module: %s signal_name : %s \n", node->node.ext_connect->inst_module_name, node->node.ext_connect->signal_name);		
	}
}

void print_relation(Relation* relation){
	printf("<--Signal name: %s line: %d Module :%s\n", relation->signal_name, relation->line_num, relation->module_name);
}

unsigned my_strnum(char* p, char c){
	unsigned int num=0;
	while(*p!='\0'){
		if(*p==c) { ++num; }
		++p;
	}
	printf("ALZ num=%d \n", num);
	return num;
}
GRNode* gveri_node_parse(char* p) {
	GRNode* node;
	char* pDigit,*pRelation;
	unsigned first;
	ExtConnect* pExt;
	char* digits;
	node = (GRNode*)malloc(sizeof(GRNode));
	init_grnode(&node);
	digits=(char*)malloc(sizeof(char)*32);
	memset(digits,'\0',32);

	first = my_strnum(p,':'); 
	//printf("First =%u ", first);
	if (first<1) return NULL;
	node->first=first;
	if(first==1) {
		pDigit=strchr(p, '_');
		pRelation=strchr(pDigit+1, ':');
		if(*(pRelation+1)=='d') {
			node->type=	GDRIVER;	
		}else if(*(pRelation+1)=='l') {
			node->type=GLOADER;	
		}else if (*(pRelation+1)=='i'){
			node->type=GIMPLICIT;	
		}
		memcpy(digits, pDigit+1, pRelation-pDigit+1);
		node->node.line_num=atoi(digits);
	}else if(first==2) {
		//printf("First =2 \n");
		pExt = (ExtConnect*)malloc(sizeof(ExtConnect));
		init_extconnect(&pExt);
		pRelation=strchr(p, ':');
		memcpy(pExt->inst_module_name, p, pRelation-p);

		if(*(pRelation+1)=='d') {
			node->type=	GDRIVER;	
		}else if(*(pRelation+1)=='l') {
			node->type=GLOADER;	
		}else if (*(pRelation+1)=='i'){
			node->type=GIMPLICIT;	
		}

		pDigit=strchr(pRelation+1, ':');
		strcpy(pExt->signal_name, pDigit+1);
		node->node.ext_connect=pExt;
	}

	print_grnode(node);
	return node;
		
}

Relation* gveri_relation_parse(char* line){
	Relation* relation;
	GRNode* gr_last;
	GRNode* gr_cur;
	int first;
	char* pch;
	char* pline;
	int field=0;
	relation = (Relation*)malloc(sizeof(Relation));
	init_relation(&relation);
	pch=strtok(line, " \t");
	while(pch!=NULL) {
		//printf("filed:%s\n", pch);
		if(field==0) {//The signals field
			pline = strchr(pch, '_');
			memcpy(relation->signal_name, pch, pline-pch);	
			relation->line_num = atoi(pline+1);
		}else if(field==1) { //The module name field
			strcpy(relation->module_name, pch);
		} else if (field>=2) {
			gr_cur = gveri_node_parse(pch);
			if(gr_cur) {
				if(relation->relations==NULL){
					relation->relations=gr_cur;
					gr_last = gr_cur;
				}else {
					gr_last->next = gr_cur;
					gr_last= gr_cur;
				}
			}
		}
		pch = strtok(NULL, " \t");

		field++;
	}
	print_relation(relation);
	return relation;
}
void load_relation_tag(char* file_name) {
	FILE* fp=fopen("relation.tag","r");
	char * line = NULL;
	size_t len=0;
	ssize_t read;
	
	Relation* root=NULL,*child=NULL;
	Relation* last=NULL;
	if(fp==NULL){
		printf("ALZ : Cannot open the file: relation.tag\n");
		exit(1);
	}
	while((read=getline(&line, &len, fp))!=-1){
		if(line[0]=='#') {
			continue;		
		}else if (line[0]=='+'){
			break;
		}else{	
			printf("-->Line: %s\n",line);
			child = gveri_relation_parse(line);
			if(root==NULL) {
				root = child;
				last = child;
			}else {
				last->next = child;
				last = child;
			}
			
		}
	} //End file pase
	
}
