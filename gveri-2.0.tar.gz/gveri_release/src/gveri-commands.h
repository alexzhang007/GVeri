#ifndef __GVERI_COMMANDS_H__
#define __GVERI_COMMANDS_H__

#include <gtk/gtkaction.h>
#include <gtk/gtk.h>
#include "gveri-db.h"
#include "gveri.h"
//extern GVeriScope* root=NULL;

void		_gveri_cmd_file_new			    (GtkAction   *action, GVeriWindow *window);
void		_gveri_cmd_file_open			(GtkAction   *action, GVeriWindow *window);
void		_gveri_cmd_file_save			(GtkAction   *action, GVeriWindow *window);
void		_gveri_cmd_file_save_as			(GtkAction   *action, GVeriWindow *window);
void		_gveri_cmd_edit_preferences		(GtkAction   *action, GVeriWindow *window);
void		_gveri_cmd_help_contents		(GtkAction   *action, GVeriWindow *window);
void		_gveri_cmd_help_about			(GtkAction   *action, GVeriWindow *window);
void 		_gveri_cmd_load_design			(GtkAction   *action, GVeriWindow *window);
void		_gveri_cmd_quit					(GtkAction   *action, GVeriWindow *window);
void		_gveri_cmd_lock_content			(GtkAction   *action, GVeriWindow *window);
void		_gveri_cmd_unlock_content		(GtkAction   *action, GVeriWindow *window);
void		_gveri_cmd_view_waveform		(GtkAction   *action, GVeriWindow *window);
void		_gveri_cmd_view_all_signals		(GtkAction   *action, GVeriWindow *window);
void		_gveri_cmd_parent_module		(GtkAction   *action, GVeriWindow *window);
void		_gveri_cmd_child_module			(GtkAction   *action, GVeriWindow *window);
void		_gveri_cmd_up					(GtkAction   *action, GVeriWindow *window);
void		_gveri_cmd_down					(GtkAction   *action, GVeriWindow *window);
void		_gveri_cmd_backward_history		(GtkAction   *action, GVeriWindow *window);
void		_gveri_cmd_forward_history		(GtkAction   *action, GVeriWindow *window);
void		_gveri_cmd_simulation			(GtkAction   *action, GVeriWindow *window);
void		_gveri_cmd_find_module			(GtkAction   *action, GVeriWindow *window);
void		_gveri_cmd_find_file			(GtkAction   *action, GVeriWindow *window);
void		_gveri_cmd_find_string			(GtkAction   *action, GVeriWindow *window);

#endif
