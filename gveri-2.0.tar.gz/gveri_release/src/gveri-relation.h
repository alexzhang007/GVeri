#ifndef __GVERI_RELATION_H__
#define __GVERI_RELATION_H__
#define FILE_NAME_LEN  30
#define VARI_NAME_LEN  30
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef enum{
	GIMPLICIT,GDRIVER, GLOADER,		
}GConnect; //The connect type
//------------For variable list-------------------------------------
typedef struct ext_connect{
	char* inst_module_name;
	char* signal_name;
}ExtConnect;
typedef struct grnode{
	union {
		unsigned line_num;
		ExtConnect* ext_connect;
	} node;
	unsigned first;
	GConnect type;
	struct grnode * next;
}GRNode;

typedef struct relation{
	char* signal_name;
	char* module_name;
	unsigned line_num;
	GRNode* relations;
	
	struct relation* next;
}Relation;
//---------------- for module connect list----------------------------------
typedef struct connect{
	char* sub_sig_name;
	char* par_sig_name;
	GConnect sub_gcon_par;  //->: sub module signal drive signals in parent module, <-: sub module signal is loaded by signals  in parent module
	struct connect* next;
}Connect;
typedef struct connection{
	char* file_name;
	char* sub_scope_name;
	char* par_scope_name;
	Connect* head_signal_connect;
}Connection;
//--------------member function-------------------------------------
void init_connect(Connect** connect);
void init_connection(Connection** connection);
void init_relation(Relation** relation);
void init_extconnect(ExtConnect** ext_connect);
void init_grnode(GRNode** grnode);

void print_grnode(GRNode* node);

void load_relation_tag(char* file_name);
#endif

