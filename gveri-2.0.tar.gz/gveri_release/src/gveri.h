#ifndef __GVERI_H__
#define __GVERI_H__
#include <gtksourceview/gtksourceview.h>
#include <gtksourceview/gtksourcebuffer.h>
#include <gtksourceview/gtksourcelanguage.h>
#include <gtksourceview/gtksourcelanguagesmanager.h>
typedef enum {
	GVERI_FIND, //Find all word and mark;
	GVERI_DEL, //d delete a  line
	GVERI_COPY,//y
	GVERI_PASTE,//p
	GVERI_NEXT,//n
	GVERI_PREV, //N
	GVERI_SAVE, 
	GVERI_QUIT,
	GVERI_REPLACE,
	GVERI_REPLACE_ALL,
	GVERI_GOTO_LINE,
	GVERI_WRAP_MODE,
	GVERI_NOWRAP_MODE
}GVeriCmd;


typedef struct gveri_window{
	GtkWidget *window;

	GtkWidget *vbox;
	GtkWidget *hbox;
	//Menubar and toolbar
	GtkWidget *menubar;
	GtkWidget *toolbar;
	
	//Left Panel
	GtkWidget* leftNotebook;
	  //Treeview
 	GtkWidget *view;
 	GtkTreeSelection *selection; 
	GtkWidget *scrolled_win;
  	GtkWidget *frame;
 	GtkWidget *table;
  	GtkWidget *labelTreeView;

	//listview
  	GtkWidget* listView;
  	GtkWidget *labelListView;
  	GtkWidget *frameListView;
  	GtkWidget *scrolled_win_listView;
  	GtkTreeSelection *selectionListView; 

    //TextView
    GtkWidget *textView;
	//GtkTextBuffer *buffer;
	GtkSourceBuffer *buffer;
    GtkWidget *frameInTextView;
    GtkWidget *scrolled_win_text;
	GtkSourceLanguagesManager* lm;
	GtkSourceLanguage *language;
	GtkWidget* fileTitle;//For the vim adapted title. 
	GtkWidget* vboxText;  //For the textview/fileTitle/cmdLine
	gchar* copy_text;
	gchar* cmd_line;
	gchar* search_content;//For the n/N command;
    GtkWidget* cmdView;//For typing the command View
    GtkTextBuffer *cmdBuf;

  
    //Bottom notebook
    GtkWidget* bottomNotebook;
  	GtkWidget* cmdTextView;
  	GtkWidget* scrolled_win_cmdView;
  	GtkWidget* labelCmdView;
  	GtkWidget* frameCmdView;
  	GtkTextBuffer *buffer_cmdView;

  	GtkWidget* hpaned;
  	GtkWidget* vpaned;
  	GString* current_doc;//string;

    //--icon start
 	GtkIconFactory *factory;

	//Statusbar
  	GtkWidget *statusbar;

	//Design file
	const gchar* design_file;
	GtkWidget* file_selection;

	GVeriList* recent_files;
  	GVeriList* current_file;//string;
}GVeriWindow;

extern gboolean verbose_flag;
void init_gveri_window(GVeriWindow** window);
GString* gveri_load_file(char* fileName);
void add_to_list(GtkWidget*list, const char* str);
void gveri_add_to_recent(GVeriWindow* window);
gboolean  gveri_malloc(char** des, char* src);
void command_line_parser(char* cmd_line, GVeriWindow* window);
#endif
