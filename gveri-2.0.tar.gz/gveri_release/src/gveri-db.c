#include "gveri-db.h"
#include "gveri.h"
GVeriScope* current_scope=NULL;
int stringCmp(char* s1, char* s2){
	while(*s1||*s2) {
		if(*s1-*s2) {
			return *s1-*s2;		
		}else {
			s2++;
			s1++;
		}
	}
	return 0;
}
void init_gveri_scope(GVeriScope** gveriScope){
	(*gveriScope)->scopeType = NONE;
	(*gveriScope)->fileName = (char*)malloc(sizeof(char)*NAME_LEN);
	(*gveriScope)->scopeName = (char*)malloc(sizeof(char)*NAME_LEN);
	(*gveriScope)->scopeInstName = (char*)malloc(sizeof(char)*NAME_LEN);
	(*gveriScope)->parent = NULL;
	(*gveriScope)->next = NULL;
	(*gveriScope)->prev = NULL;
	(*gveriScope)->child = NULL;
}

void get_filename(GVeriScope* root, char* moduleName, char** fileName){
	//char* fileName=NULL;
	GVeriScope* p=root;
	if(p) {
	  while(p) {
		int cmp=strcmp(moduleName, p->scopeName);
		//printf ("ModuleName:%s:%d,DBModuleName:%s:%d,%d, DBFileName:%s\n",moduleName, strlen(moduleName), p->scopeName,strlen(p->scopeName),cmp, p->fileName);
		if(cmp==0 && (strlen(p->fileName)>0) ) {
			if(verbose_flag)
 				printf("Enter the ret: fileName=%s\n", p->fileName);
			*fileName=(char*)malloc(sizeof(char)*NAME_LEN);
			strcpy(*fileName, p->fileName);
			current_scope = p;
			return ;
		}
		p=p->next;
	  }
	}
	p=root;
	while(p) {
		if(p&&p->child) {
			if(verbose_flag)
				printf ("Look into child : %s ModuleName=%s\n", p->child->scopeName, moduleName);
			get_filename(p->child, moduleName,fileName);				
		}
		p=p->next;

	}
}
GVeriScope* find_gveri_scope(GVeriScope* root, char* moduleName){
	GVeriScope* p=root;
	GVeriScope* pRet=NULL;
	while(p) {
		if(strcmp(moduleName, p->scopeName)==0) {
			pRet=p;
			return p;
		}else {
			if(p->child) {
				pRet=find_gveri_scope(p->child, moduleName);		
			}	
		}
		p=p->next;
	}		
	return pRet;
		
}

GVeriScope* get_parent(GVeriScope* gveriScope){
	return gveriScope->parent;		
}
GVeriScope* get_child(GVeriScope* gveriScope, int* child_num){
	GVeriScope* p=gveriScope->child;
	int childs=0;
	while(p){
		childs++;
		p = p->next;
	}
	*child_num = childs;
	return gveriScope->child;

}

void init_gveri_list(GVeriList** gveriList){
	(*gveriList)->recentFileName = (char*)malloc(sizeof(char)*NAME_LEN);		
	memset((*gveriList)->recentFileName , '\0', NAME_LEN);
	(*gveriList)->fileFullPath = (char*)malloc(sizeof(char)*(NAME_LEN*10));		
	memset((*gveriList)->fileFullPath , '\0', NAME_LEN*10);

	(*gveriList)->context = NULL;

	(*gveriList)->next = NULL;
	(*gveriList)->prev = NULL;
}
void append_gveri_list(GVeriList* root, GVeriList* last){
	GVeriList* p=root;
	while(p->next) {
		p=p->next;		
	}
	p->next = last;
	last->prev = p;
}
GVeriList* prev_gveri_list(GVeriList* root, char* currentFileName){
	GVeriList* p = root;
	while(p) {
		if(strcmp(p->recentFileName, currentFileName)==0) {
			break;		
		}else {
			p = p->next;
		}
	}
	return p->prev;		
}
GVeriList* next_gveri_list(GVeriList* root, char* currentFileName){
	GVeriList* p = root;
	while(p) {
		if(strcmp(p->recentFileName, currentFileName)==0) {
			break;		
		}else {
			p = p->next;
		}
	}
	return p->next;		
}
void print_gveri_scope(GVeriScope* root){
	GVeriScope* p=root;
	while(p) {
		if(verbose_flag)
			printf("ModuleName=%s, InstanceName=%s, fileName=%s :%d", p->scopeName, p->scopeInstName, p->fileName, strlen(p->fileName));
		if(p->parent) {
			if(verbose_flag)
				printf(" Parent filename=%s \n", p->parent->fileName);		
		}else {
			if(verbose_flag)
				printf("\n");
		}
		p=p->next;
	}
	p=root;
	while(p){
		if(p->child){
			print_gveri_scope(p->child);		
		}		
		p=p->next;
	}
}
void print_gveri_list(GVeriList* header){
	GVeriList* p=header;
	while(p) {
		if(verbose_flag)
			printf("AllFile :%s Path: %s\n", p->recentFileName, p->fileFullPath);
		p = p->next;
	}

}

char* gveri_list_get_full_path(GVeriList* root, char* fileName){
	GVeriList* p=root;
	while(p) {
		if(strcmp(fileName, p->recentFileName)==0) 
			return p->fileFullPath;
		p=p->next;
	}
}
GVeriList* gveri_list_get_test(GVeriList* root, char* fileName){
	GVeriList* p=root;
	while(p) {
		if(verbose_flag)
			printf("CMP the shortName is %s\n", p->recentFileName);
		if(strcmp(fileName, p->recentFileName)==0) 
			return p;
		p=p->next;
	}
	return NULL;
			
}
