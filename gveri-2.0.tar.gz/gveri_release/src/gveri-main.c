#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>
#include <getopt.h>
#include "gveri-db.h"
#include "gveri-xml.h"
#include "gveri-ui.h"
#include "gveri-lst.h"
#include "gveri.h"
#include <unistd.h>
#include <fcntl.h>

#define BUFSIZE 65536

GVeriScope* root=NULL;
//GtkTextBuffer *buffer;
GVeriList* header=NULL; //all the files loaded into GVeri
gboolean verbose_flag = FALSE;
char* info="Scaling GVeri (TM)\nVersion 2011.07.01 --Sat Jul 30\nCopyright (c) 2010-2021 by Scaling Inc. \nAll rights Reserved\n";
//FOr TreeView
enum
{
  COLUMN = 0,
  NUM_COLS
} ;
//For List
enum
{
  LIST_ITEM = 0,
  N_COLUMNS
};
gboolean gveri_malloc(char** des, char* src){
	int size = sizeof(src);
    (*des) = (char*)malloc(sizeof(char)*size);
	if((*des)==NULL) {
		return FALSE;		
	}
	memset((*des), '\0', size);
	strcpy((*des), src);
	return TRUE;
}
void command_line_parser(char* cmd_line, GVeriWindow* window){
	char *pch;
	GtkTextBuffer *buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(window->textView));
	GtkTextIter start_find, end_find;
	GtkTextIter start_match, end_match;
	char* set_label_text;
	char* fileName = window->current_file->fileFullPath;
	int find_num=0;
	gint line_num;
	int match_index=0;
	char* pmatch;
	char* pFind, *pReplace;
	GVeriCmd cmdType;
    char num_set[]="0123456789";
  	if(verbose_flag)
	printf("ALZ: the current file name is %s\n", fileName);
	if(cmd_line[0]==':') {//Save/Quit/Replace
		switch (cmd_line[1]) {
			case 'w':
			case 'W':
				cmdType = GVERI_SAVE;
			break;
			case 'q':
			case 'Q':
				cmdType = GVERI_QUIT;
			break;

		}
		pch = cmd_line+1;
		if(strspn(pch, num_set)==strlen(pch)){
			cmdType = GVERI_GOTO_LINE;		
		}else if(strncmp(pch,"set",3)==0) {
			pch = pch+4;
			if(strncmp(pch,"nowrap", 6)==0) {
				cmdType = 	GVERI_NOWRAP_MODE;	
			}else if (strncmp(pch, "wrap",4)==0) {
				cmdType = GVERI_WRAP_MODE;
			}
		}

		if(cmd_line[1]=='%'){ //Replace function
			switch (cmd_line[2]) {
				case 's':
					cmdType = GVERI_REPLACE;
					pch = cmd_line+3;
					pmatch = strtok(pch , "/");
					while(pmatch != NULL) {
						if(match_index ==0 ) {
							gveri_malloc(&pFind, pmatch);
						//printf("%d : %s\n", match_index, pmatch);
						}else if (match_index ==1) {
							gveri_malloc(&pReplace, pmatch);
						//printf("%d : %s\n", match_index, pmatch);
						} else if (match_index == 2) {
						//printf("%d : %s\n", match_index, pmatch);
							if(*pmatch=='g')
								cmdType = GVERI_REPLACE_ALL;								
						}
						pmatch = strtok(NULL, "/");
						match_index++;	
					}
  					if(verbose_flag)
					printf ("ALZ :: Find %s Replace with %s\n", pFind, pReplace);
				break;
			}
		}

	}else if (cmd_line[0]=='/'){ //Search function
			cmdType = GVERI_FIND;
			pch = cmd_line+1;
	}
	switch (cmdType) {
		case GVERI_QUIT:

		break;
		case GVERI_SAVE:

		break;
		case GVERI_FIND:
  			if(verbose_flag)
				printf ("ALZ : Find content :%s|\n", pch);
			gveri_malloc(&(window->search_content), pch);
			gtk_text_buffer_get_start_iter(buffer, &start_find);
			gtk_text_buffer_get_end_iter(buffer, &end_find);
			gtk_text_buffer_remove_tag_by_name(buffer, "yellow_bg", &start_find, &end_find);  
			while ( gtk_text_iter_forward_search(&start_find, pch, GTK_TEXT_SEARCH_TEXT_ONLY | GTK_TEXT_SEARCH_VISIBLE_ONLY, &start_match, &end_match, NULL) ) {
				gtk_text_buffer_apply_tag_by_name(GTK_TEXT_BUFFER(buffer), "yellow_bg", &start_match, &end_match);
				int offset = gtk_text_iter_get_offset(&end_match);
				gtk_text_buffer_get_iter_at_offset(buffer,&start_find, offset);
				find_num++;
			}
  			if(verbose_flag)
				printf ("We find %d \n", find_num);
			char *num_str=(char*)malloc(sizeof(char)*10);
			sprintf(num_str, "%d", find_num);
			int len = strlen(fileName) +13; //10 is the number
			set_label_text = (char*)malloc(sizeof(char)*len);
			memset(set_label_text, '\0',  len);
			strcat (set_label_text , fileName);
			strcat (set_label_text , " : ");
			strcat (set_label_text , num_str);
  			gtk_label_set_text(GTK_LABEL(window->fileTitle), set_label_text);
		break;
		case GVERI_REPLACE_ALL:
			gtk_text_buffer_get_start_iter(buffer, &start_find);
			gtk_text_buffer_get_end_iter(buffer, &end_find);
			while ( gtk_text_iter_forward_search(&start_find, pFind, GTK_TEXT_SEARCH_TEXT_ONLY | GTK_TEXT_SEARCH_VISIBLE_ONLY, &start_match, &end_match, NULL) ) {
				int offset = gtk_text_iter_get_offset(&end_match);
				gtk_text_buffer_delete(buffer, &start_match, &end_match);
				gtk_text_buffer_insert(buffer, &start_match, pReplace, strlen(pReplace));
				gtk_text_buffer_get_iter_at_offset(buffer,&start_find, offset);
				find_num++;
			}
			num_str=(char*)malloc(sizeof(char)*10);
			sprintf(num_str, "%d", find_num);
			len = strlen(fileName) +13; //10 is the number
			set_label_text = (char*)malloc(sizeof(char)*len);
			memset(set_label_text, '\0',  len);
			strcat (set_label_text , fileName);
			strcat (set_label_text , " : ");
			strcat (set_label_text , num_str);
  			gtk_label_set_text(GTK_LABEL(window->fileTitle), set_label_text);
			
		break;

		case GVERI_GOTO_LINE:
		    line_num = atoi(pch) -1;
  			if(verbose_flag)
				printf ("ALZ : Goto line :%d|\n", line_num);
			gtk_text_buffer_get_start_iter(buffer, &start_find);
			gtk_text_iter_set_line(&start_find, line_num );
			gtk_text_buffer_place_cursor(buffer,&start_find );
			gtk_text_view_scroll_to_iter (GTK_TEXT_VIEW(window->textView), &start_find, 0.25, FALSE, 0, 0.5);
			gtk_text_view_place_cursor_onscreen(GTK_TEXT_VIEW(window->textView));
		break;

		case GVERI_WRAP_MODE:
  			gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (window->scrolled_win_text), GTK_POLICY_NEVER, GTK_POLICY_AUTOMATIC);
			gtk_text_view_set_wrap_mode (GTK_TEXT_VIEW(window->textView),GTK_WRAP_WORD );
		break;
		case GVERI_NOWRAP_MODE:
  			gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (window->scrolled_win_text), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
			gtk_text_view_set_wrap_mode (GTK_TEXT_VIEW(window->textView),GTK_WRAP_NONE );
		break;

	}
		
}

gboolean cmdView_key_pressed(GtkWidget * cmdView, GdkEventKey* event, GVeriWindow *window){
	GtkTextIter iter;
	GtkTextIter start_iter;
	GtkTextIter start_match, end_match;
	if(event->keyval==GDK_Return) {
		gtk_text_buffer_get_start_iter (window->cmdBuf, &start_iter);
		gtk_text_buffer_get_end_iter (window->cmdBuf, &iter);
		window->cmd_line = gtk_text_buffer_get_text (window->cmdBuf, &start_iter, &iter, FALSE);
		gtk_text_buffer_delete (window->cmdBuf, &start_iter, &iter);
		start_iter = iter;
		gtk_text_iter_forward_char(&iter);//To move to the position behind \n
		gtk_text_buffer_delete (window->cmdBuf, &start_iter, &iter);
		gtk_text_view_set_cursor_visible ( GTK_TEXT_VIEW(window->cmdView) , FALSE);
		gtk_text_view_set_cursor_visible ( GTK_TEXT_VIEW(window->textView)   , TRUE);
		gtk_text_view_place_cursor_onscreen(GTK_TEXT_VIEW(window->textView));
  		if(verbose_flag)
			printf("ALZ : The cmd : %s \n", window->cmd_line);
		command_line_parser(window->cmd_line, window);
		return TRUE;
	}
	return FALSE;
}


void init_gveri_window(GVeriWindow** window){
	/*(*window)->window = NULL;
	(*window)->vbox   = NULL;
	(*window)->hbox   = NULL;
	(*window)->menubar= NULL;
	(*window)->toolbar= NULL;
	(*window)->leftNotebook= NULL;
	(*window)->view= NULL;
	(*window)->selection= NULL;
	(*window)->scrolled_win= NULL;
	(*window)->table= NULL;
	(*window)->labelTreeView = NULL;
	(*window)->listView = NULL;
	*/
	(*window)->recent_files = NULL;
	(*window)->current_file = NULL;
	(*window)->copy_text = NULL;
	(*window)->cmd_line=NULL;
	(*window)->search_content = NULL;

}
void
add_to_list(GtkWidget *list, const char *str)
{
  GtkListStore *store;
  GtkTreeIter iter;

  store = GTK_LIST_STORE(gtk_tree_view_get_model(GTK_TREE_VIEW(list)));

  gtk_list_store_append(store, &iter);
  gtk_list_store_set(store, &iter, LIST_ITEM, str, -1);
}

void selection_made( GtkWidget      *widget, GVeriWindow*        data )
{
   
  GtkTreeIter iter;
  GtkTreeModel *model;
  char *value;
  char title[80]="GVeri ";
  char *full_path;
  GVeriList* p;
  p = (GVeriList*)malloc(sizeof(GVeriList));

  if (gtk_tree_selection_get_selected(
      GTK_TREE_SELECTION(widget), &model, &iter)) {

    gtk_tree_model_get(model, &iter, LIST_ITEM, &value,  -1);
  	if(verbose_flag)
		printf("File selected : %s \n", value);
	//strcpy((char*)(*data),value)
	full_path = gveri_list_get_full_path(header, value);
	if(full_path) {
		strcat(title, full_path);	
     	gtk_window_set_title(GTK_WINDOW(data->window), title);
  		gtk_label_set_text(GTK_LABEL(data->fileTitle), full_path);
		//open the file in the buffer;
		data->current_doc = gveri_load_file(full_path);
  		gtk_text_buffer_set_text(GTK_TEXT_BUFFER(data->buffer), data->current_doc->str, -1);				
		gtk_source_view_set_show_line_numbers(GTK_SOURCE_VIEW(data->textView),TRUE);//
		gtk_source_view_set_highlight_current_line(GTK_SOURCE_VIEW(data->textView),TRUE);//
		gtk_source_view_set_auto_indent(GTK_SOURCE_VIEW(data->textView),TRUE); //

		p->fileFullPath = full_path;
		int size= strlen(data->current_doc->str);
		p->context = (char*)malloc(sizeof(char)*(size+1));
		strcpy(p->context, data->current_doc->str);
		
		if(data->recent_files==NULL) {
			data->recent_files = p;
			data->current_file = p;
		}	else {
			data->current_file->next = p;
			p->prev= data->current_file;

			data->current_file = p;
		}
	}
     g_free(value);
  }


    return;
}

static gboolean delete_event( GtkWidget *widget,
                              GdkEvent *event,
                              gpointer data )
{
  gtk_main_quit ();
  return FALSE;
}
static void create_menu(GVeriWindow* window){
	GtkActionGroup *action_group;
	GtkAction *action;
	GtkUIManager* manager;
	//GtkWidget *menubar;
	//GtkWidget *toolbar;
	GError *error = NULL;

	manager = gtk_ui_manager_new();
	gtk_window_add_accel_group (GTK_WINDOW (window->window), gtk_ui_manager_get_accel_group (manager));
	action_group = gtk_action_group_new ("GveriWindowAlwaysSensitiveActions");
	gtk_action_group_set_translation_domain (action_group, NULL);
	gtk_action_group_add_actions (action_group, gveri_always_sensitive_menu_entries, G_N_ELEMENTS(gveri_always_sensitive_menu_entries),  window);
	gtk_ui_manager_insert_action_group (manager, action_group, 0);
	g_object_unref (action_group);

	action_group = gtk_action_group_new ("GveriWindowActions");
	gtk_action_group_set_translation_domain (action_group, NULL);
	gtk_action_group_add_actions (action_group,  gveri_menu_entries, G_N_ELEMENTS (gveri_menu_entries),  window);
	gtk_ui_manager_insert_action_group (manager, action_group, 0);
	g_object_unref (action_group);

    gtk_ui_manager_add_ui_from_file (manager, GVERI_DATADIR "ui/gveri-ui.xml", &error);
	if (error != NULL)
	{
		g_warning ("Could not merge gveri-ui.xml: %s", error->message);
		g_error_free (error);
	}


	window->menubar = gtk_ui_manager_get_widget (manager, "/MenuBar");
	window->toolbar = gtk_ui_manager_get_widget (manager, "/ToolBar");
	gtk_toolbar_set_style (	GTK_TOOLBAR (window->toolbar),	GTK_TOOLBAR_ICONS);
    gtk_toolbar_set_icon_size (	GTK_TOOLBAR (window->toolbar),	GTK_ICON_SIZE_MENU);


	gtk_box_pack_start (GTK_BOX (window->vbox), window->menubar, FALSE, FALSE, 0);
	gtk_box_pack_start (GTK_BOX (window->vbox), window->toolbar, FALSE, FALSE, 0);

}


void  on_changed(GtkWidget *widget, GVeriWindow* window) 
{
  GtkTreeIter iter;
  GtkTreeModel *model;
  char *value;
  char *fileName;
  char moduleName[NAME_LEN];
  GString *string;
  GVeriList* p;
  p = (GVeriList*)malloc(sizeof(GVeriList));
  init_gveri_list(&p);

  if (gtk_tree_selection_get_selected(GTK_TREE_SELECTION(widget), &model, &iter)) {

    gtk_tree_model_get(model, &iter, COLUMN, &value,  -1);
    gtk_statusbar_push(GTK_STATUSBAR(window->statusbar),
    gtk_statusbar_get_context_id(GTK_STATUSBAR(window->statusbar), value), value);

    sscanf(value, "%*s %s",moduleName );	
	get_filename(root, moduleName, &fileName);
  	if(verbose_flag)
		printf("OnChange:%s\n", fileName);
	if(fileName) {
  		if(verbose_flag)
			printf("ALZ : Open %s\n", fileName);
    	string = gveri_load_file(fileName);
  	    gtk_text_buffer_set_text(GTK_TEXT_BUFFER(window->buffer), string->str, -1);
		p->fileFullPath = fileName;
  		gtk_label_set_text(GTK_LABEL(window->fileTitle), fileName);
		p->context = string->str;
		if(window->recent_files==NULL) {
			window->recent_files = p;
			window->current_file = p;
		}	else {
			window->current_file->next = p;
			p->prev= window->current_file;

			window->current_file = p;
		}
	}else{
  		if(verbose_flag)
			printf("ALZ : cannot find the filename contain %s\n", moduleName);		
	}
  	if(verbose_flag)
		printf("Alzhang: THe current scope is %s\n", current_scope->scopeName);

    g_free(value);
  }
}

void gveri_gtk_tree_store_load(GVeriScope* header, GtkTreeStore *treestore, GtkTreeIter* toplevel){
	char name[NAME_LEN*2];
	GVeriScope *p=header;
	GtkTreeIter* child;
  	while(p) {
		if(p==root) {
	  		gtk_tree_store_append(treestore, toplevel, NULL);
	    	sprintf(name, "%s %s",p->scopeInstName, p->scopeName);
  			if(verbose_flag)
				printf("Gver_load: %s\n",name);
  	    	gtk_tree_store_set((treestore), toplevel, COLUMN, name, -1);
			child =toplevel;
			gveri_gtk_tree_store_load(p->child,treestore, child);
		}else {
			child=(GtkTreeIter*)malloc(sizeof(GtkTreeIter));
	  		gtk_tree_store_append(treestore, child,toplevel);
	    	sprintf(name, "%s %s",p->scopeInstName, p->scopeName);
  			if(verbose_flag)
				printf("Gver_load: %s\n",name);
  	    	gtk_tree_store_set(treestore, child, COLUMN, name, -1);
			gveri_gtk_tree_store_load(p->child,treestore, child);
		}
	    p= p->next;		  
    }
    //load the childs
	/*
	p =header;
	child=toplevel;
	while(p) {
		if(p->child) {
			gveri_gtk_tree_store_load(p->child,treestore, child);
		}
		p=p->next;
	}
	*/
}

static GtkTreeModel *
create_and_fill_model (void)
{
  GtkTreeStore *treestore;
  GtkTreeIter toplevel, child;
  GtkTreeIter* p1,*p2;
  char name[NAME_LEN*2];
  gboolean valid=FALSE;
	
  GVeriScope* p;
  int ret = gveri_xml_load(&root);
  if (ret==0)
		return NULL;
  p=root;
 
  if(p) {
  	if(verbose_flag)
		printf("Xml-data load isOK\n ");		  
  	if(verbose_flag)
  		printf("Gver_load_: %s\n",p->scopeName);
  }
  print_gveri_scope(root);
  treestore = gtk_tree_store_new(NUM_COLS, G_TYPE_STRING);
  //gtk_tree_store_append(treestore, &toplevel, NULL);
  //sprintf(name, "%s (%s)",p->scopeInstName, p->scopeName);
  
  gveri_gtk_tree_store_load(root, treestore, &toplevel );


  return GTK_TREE_MODEL(treestore);
}



static GtkWidget *
create_view_and_model (void)
{
  GtkTreeViewColumn *col;
  GtkCellRenderer *renderer;
  GtkWidget *view;
  GtkTreeModel *model;



  view = gtk_tree_view_new();

  col = gtk_tree_view_column_new();
  //gtk_tree_view_column_set_title(col, "Module");
  gtk_tree_view_set_headers_visible(GTK_TREE_VIEW(view), FALSE);
  gtk_tree_view_append_column(GTK_TREE_VIEW(view), col);

  renderer = gtk_cell_renderer_text_new();
  gtk_tree_view_column_pack_start(col, renderer, TRUE);
  gtk_tree_view_column_add_attribute(col, renderer, 
      "text", COLUMN);

  model = create_and_fill_model();
  gtk_tree_view_set_model(GTK_TREE_VIEW(view), model);
  g_object_unref(model); 

  return view;
}
static void mark_set_cb(GtkTextBuffer* buffer_cmdView, const GtkTextIter* new_location, GtkTextMark* mark, gpointer data){
	GtkTextMark* input_mark;
	GtkTextMark* last_mark;
	GtkTextIter mstart,mend;
	input_mark = gtk_text_buffer_get_mark(buffer_cmdView, "input");
	gtk_text_buffer_get_iter_at_mark(buffer_cmdView, &mstart, input_mark);
	last_mark = gtk_text_buffer_get_insert(buffer_cmdView);
	gtk_text_buffer_get_iter_at_mark(buffer_cmdView, &mend, last_mark);
	gtk_text_view_set_editable(GTK_TEXT_VIEW(data),gtk_text_iter_compare(&mend, &mstart)!=-1 );	
		
}
char* find_init_last_space(char* line){
	char* pch=	line;
	while(*pch==' '||*pch=='\t' ){
		pch++;		
	}
	return pch;
}
char* get_shell_return_value(char* line){
	char ret[BUFSIZE];
	FILE *fp;
	char* buffer;
	char *pch;
	int len=0;
	int len_pre=0;
	int len_ori=0;
	ret[BUFSIZE]='\0';
	buffer=(char*)malloc(sizeof(char)*BUFSIZE);
	memset(buffer, '\0',BUFSIZE);
	//preprocess the cd ../ or cd some_directory 
	pch=find_init_last_space(line);
	if(pch!=line) {
		len_ori=strlen(line);
		len_pre=strlen(pch);
		memcpy(line, pch, len_pre);
		memset(line+1, '\0',len_ori-len_pre);
	}
	//
	if(strncmp(line, "cd", 2)==0) {
  		if(verbose_flag)
			printf("SHell cd command\n");
		pch=strrchr(line, ' ');
		if(pch) {
  			if(verbose_flag)
				printf("dir=%s\n", pch+1);
			chdir(pch+1);		
		}
		return "\0";
	}
	fp=popen(line, "r");
	if(fp==NULL) {
  		if(verbose_flag)
			printf("SHell call is failed\n");
		return NULL;		
	}else {
		while((fgets(ret, sizeof(ret), fp))!=NULL){	
			//printf("|%s|%d\n", ret, strlen(ret));
			if(len>BUFSIZE) {
  				if(verbose_flag)
					printf("ALZ : len is large than BUFSIZE\n");		
			} else {
				memcpy(buffer+len, ret, strlen(ret)-1);
				strcat(buffer, " ");
				len+=strlen(ret);
			}
		}	
	}
  	if(verbose_flag)
		printf("shell : %s\n", ret);
	pclose(fp);
	return buffer;
}
gboolean command_parse(GtkWidget * window,GdkEventKey* event, GtkTextBuffer *buffer_cmdView) {
	GtkTextIter iterInp;
	GtkTextIter iterCur;
	GtkTextIter iterLine;
	GtkTextIter iterShell;

	GtkTextMark* inp_mark;
	GtkTextMark* lin_mark;
	gchar* line;
	char* shell_return_value;
	int line_num=0;
	if(event->keyval==GDK_Return) {
		lin_mark = gtk_text_buffer_get_mark(buffer_cmdView, "input-line");
		inp_mark = gtk_text_buffer_get_mark(buffer_cmdView, "input");
		//Get the command line
		gtk_text_buffer_get_iter_at_mark(buffer_cmdView, &iterInp, inp_mark);
		gtk_text_buffer_get_end_iter(buffer_cmdView, &iterCur);
		line = gtk_text_iter_get_text( &iterInp, &iterCur);

		line_num = gtk_text_iter_get_line(&iterCur); 
  		if(verbose_flag)
			printf("ALZ:Key press %d :%s\n",line_num,  line);
		shell_return_value=get_shell_return_value(line);
  		if(verbose_flag)
			printf("SHELL=%s<--\n", shell_return_value);

		//Make the line blue
		gtk_text_buffer_get_iter_at_mark(buffer_cmdView, &iterLine, lin_mark);
		gtk_text_buffer_apply_tag_by_name(buffer_cmdView, "blue_fg",&iterLine,&iterCur);
		gtk_text_buffer_insert(buffer_cmdView, &iterCur, "\n",1);
		//print the shell return value
		gtk_text_buffer_get_end_iter(buffer_cmdView, &iterShell);
		gtk_text_buffer_insert(buffer_cmdView, &iterShell, shell_return_value,strlen(shell_return_value));
		gtk_text_buffer_get_end_iter(buffer_cmdView, &iterCur);
		gtk_text_buffer_apply_tag_by_name(buffer_cmdView, "red_fg",&iterShell,&iterCur);
		if(strlen(shell_return_value)>0) {
			gtk_text_buffer_insert(buffer_cmdView, &iterCur, "\n",1);
		}

		
		//Prepare the new line
		gtk_text_buffer_get_end_iter(buffer_cmdView, &iterCur);
		gtk_text_buffer_move_mark(buffer_cmdView, lin_mark, &iterCur);
		gtk_text_buffer_insert(buffer_cmdView, &iterCur, ">> ",3);
		gtk_text_buffer_get_end_iter(buffer_cmdView, &iterCur);
		gtk_text_buffer_move_mark(buffer_cmdView, inp_mark, &iterCur);
		
		gtk_text_buffer_place_cursor(buffer_cmdView, &iterCur);
		

		free(line);
		return TRUE;

	}
	return FALSE;

}
gboolean key_pressed(GtkWidget * textView, GdkEventKey* event, GVeriWindow* window) {

  GtkTextIter start_sel, end_sel;
  GtkTextIter start_find, end_find;
  GtkTextIter start_match, end_match;
  GtkTextMark* cursor;
  GtkTextIter iter, start_iter;

  gboolean selected;	
  gchar *text;		  
  static int line_num=0;
  GtkTextBuffer *buffer =GTK_TEXT_BUFFER( window->buffer);


  if ((event->type == GDK_KEY_PRESS) && 
     (event->state & GDK_CONTROL_MASK)) {

    switch (event->keyval)
    {
      case GDK_m :
        selected = gtk_text_buffer_get_selection_bounds(buffer, &start_sel, &end_sel);
        if (selected) {
        	gtk_text_buffer_get_start_iter(buffer, &start_find);
        	gtk_text_buffer_get_end_iter(buffer, &end_find);

        	gtk_text_buffer_remove_tag_by_name(buffer, "gray_bg", &start_find, &end_find);  
        	text = (char *) gtk_text_buffer_get_text(buffer, &start_sel, &end_sel, FALSE);

        while ( gtk_text_iter_forward_search(&start_find, text, 
                GTK_TEXT_SEARCH_TEXT_ONLY | 
                GTK_TEXT_SEARCH_VISIBLE_ONLY, 
                &start_match, &end_match, NULL) ) {

          gtk_text_buffer_apply_tag_by_name(buffer, "gray_bg",&start_match, &end_match);
          int offset = gtk_text_iter_get_offset(&end_match);
          gtk_text_buffer_get_iter_at_offset(buffer, &start_find, offset);
        }

        g_free(text);
      }

      break;

      case GDK_r:
        gtk_text_buffer_get_start_iter(buffer, &start_find);
        gtk_text_buffer_get_end_iter(buffer, &end_find);
      
        gtk_text_buffer_remove_tag_by_name(buffer, "gray_bg", &start_find, &end_find);  
      break;
	  case GDK_w: //Ctrl+w to select the word
        selected = gtk_text_buffer_get_selection_bounds(buffer, &start_sel, &end_sel);
      	if (selected) {
        	text = (char *) gtk_text_buffer_get_text(buffer, &start_sel, &end_sel, FALSE);
		
  			if(verbose_flag)
				printf ("ALZ : you selected :%s\n", text);
		}

	  break;

    }
  }
    if(event->keyval==GDK_Escape) {
		gtk_text_view_set_editable(GTK_TEXT_VIEW(window->textView), FALSE);
  		gtk_text_view_set_editable(GTK_TEXT_VIEW(window->cmdView), TRUE);
		gtk_text_view_set_cursor_visible ( GTK_TEXT_VIEW(window->cmdView) , TRUE);
		//gtk_text_view_set_cursor_visible(GTK_TEXT_VIEW(window), FALSE);
  		if(verbose_flag)
			printf("ALZ : Escape the edit mode, and enter the Visual mode\n");
	} else if (event->keyval == GDK_I || event->keyval== GDK_i){
		gtk_text_view_set_editable(GTK_TEXT_VIEW(window->textView), TRUE);
  		if(verbose_flag)
			printf("ALZ : enter the edit mode\n");
		return TRUE;
			
	} else if(event->keyval == GDK_y){
		//Get the mark at the cursor
		cursor = gtk_text_buffer_get_mark (buffer, "insert");
		//Get the iter at the cursor
		gtk_text_buffer_get_iter_at_mark (buffer, &iter, cursor);
		gtk_text_iter_set_line_offset(&iter, 0);
		start_iter = iter;
		gtk_text_iter_forward_to_line_end (&iter);
		window->copy_text =  gtk_text_buffer_get_text  (buffer, &start_iter, &iter, FALSE);
  		if(verbose_flag)
			printf("ALZ : Get the cursor content : %s\n", window->copy_text);

	} else if(event->keyval == GDK_p ){
		if(window->copy_text==NULL) {
			return FALSE;		
		}
		gint len=strlen(window->copy_text);
		cursor = gtk_text_buffer_get_mark (buffer, "insert");
		gtk_text_buffer_get_iter_at_mark (buffer, &iter, cursor);
		gtk_text_iter_forward_to_line_end (&iter);
		//Firstly, insert the \n
		gtk_text_buffer_insert(buffer, &iter, "\n",1 );
		gtk_text_view_set_editable(GTK_TEXT_VIEW(window->textView), TRUE);
		gtk_text_buffer_insert(buffer, &iter, (gchar*)window->copy_text,len );
		gtk_text_view_set_editable(GTK_TEXT_VIEW(window->textView), FALSE);
					
	} else if (event->keyval == GDK_d ) { //Delete the current line
		cursor = gtk_text_buffer_get_mark (buffer, "insert");
		gtk_text_buffer_get_iter_at_mark (buffer, &iter, cursor);
		gtk_text_iter_set_line_offset(&iter, 0);
		start_iter = iter;
		gtk_text_iter_forward_to_line_end (&iter);
		gtk_text_buffer_delete (buffer, &start_iter, &iter);
		start_iter = iter;
		gtk_text_iter_forward_char(&iter);//To move to the position behind \n
		gtk_text_buffer_delete (buffer, &start_iter, &iter);
	} else if(event->keyval == GDK_n) { //Next
		cursor = gtk_text_buffer_get_mark (buffer, "insert");
		gtk_text_buffer_get_iter_at_mark (buffer, &iter, cursor);
		start_iter = iter;
		if ( gtk_text_iter_forward_search(&start_iter, window->search_content, GTK_TEXT_SEARCH_TEXT_ONLY | GTK_TEXT_SEARCH_VISIBLE_ONLY, &start_match, &end_match, NULL) ) {
			int offset = gtk_text_iter_get_offset(&end_match);
			gtk_text_buffer_get_iter_at_offset(buffer,&start_iter, offset);
			
			gtk_text_buffer_place_cursor(buffer,&start_iter );
			gtk_text_view_scroll_to_iter (GTK_TEXT_VIEW(window->textView), &start_iter, 0.25, FALSE, 0, 0.5);
			gtk_text_view_place_cursor_onscreen(GTK_TEXT_VIEW(window->textView));

		}
		
	} else if (event->keyval == GDK_N) { //Previous
		cursor = gtk_text_buffer_get_mark (buffer, "insert");
		gtk_text_buffer_get_iter_at_mark (buffer, &iter, cursor);
		start_iter = iter;
		if ( gtk_text_iter_backward_search(&start_iter, window->search_content, GTK_TEXT_SEARCH_TEXT_ONLY | GTK_TEXT_SEARCH_VISIBLE_ONLY, &start_match, &end_match, NULL) ) {
			int offset = gtk_text_iter_get_offset(&start_match);
			gtk_text_buffer_get_iter_at_offset(buffer,&start_iter, offset);
			
			gtk_text_buffer_place_cursor(buffer,&start_iter );
			gtk_text_view_scroll_to_iter (GTK_TEXT_VIEW(window->textView), &start_iter, 0.25, FALSE, 0, 0.5);
			gtk_text_view_place_cursor_onscreen(GTK_TEXT_VIEW(window->textView));

		}
			
	} else if(event->keyval == GDK_g) { //Go to the start of the content
		 gtk_text_buffer_get_start_iter (buffer, &start_iter);
		 gtk_text_buffer_place_cursor(buffer,&start_iter );
		 gtk_text_view_scroll_to_iter (GTK_TEXT_VIEW(window->textView), &start_iter, 0.25, FALSE, 0, 0.5);
		 gtk_text_view_place_cursor_onscreen(GTK_TEXT_VIEW(window->textView));

	} else if (event->keyval == GDK_G) { //Go to the end of the content
		 gtk_text_buffer_get_end_iter (buffer, &start_iter);
		 gtk_text_buffer_place_cursor(buffer,&start_iter );
		 gtk_text_view_scroll_to_iter (GTK_TEXT_VIEW(window->textView), &start_iter, 0.25, FALSE, 0, 0.5);
		 gtk_text_view_place_cursor_onscreen(GTK_TEXT_VIEW(window->textView));
			
	}

	

  return FALSE;
}
GString* gveri_load_file(char* fileName){
	GString* string;
	FILE* fp=fopen(fileName, "r");
	char* line=NULL;
	size_t len=0;
	ssize_t read;
	if(fp==NULL){
  		if(verbose_flag)
			printf("ALZ : Cannot open the file, filename =%s\n", fileName);
		return g_string_new("");
	}

	string=g_string_new("");
	while((read=getline(&line, &len, fp))!=-1){
		g_string_append(string, line);
	}
	fclose(fp);
	return string;

}
static void
init_list(GtkWidget *list)
{

  GtkCellRenderer *renderer;
  GtkTreeViewColumn *column;
  GtkListStore *store;

  renderer = gtk_cell_renderer_text_new();
  column = gtk_tree_view_column_new_with_attributes("List Items",renderer, "text", LIST_ITEM, NULL);
  gtk_tree_view_append_column(GTK_TREE_VIEW(list), column);

  store = gtk_list_store_new(N_COLUMNS, G_TYPE_STRING);

  gtk_tree_view_set_model(GTK_TREE_VIEW(list), GTK_TREE_MODEL(store));

  g_object_unref(store);
}

GtkWidget *create_list_view_and_model(){
 	GtkWidget* clist;
	char* label;


	clist = gtk_tree_view_new( );
	gtk_tree_view_set_headers_visible(GTK_TREE_VIEW(clist), FALSE);
	//Init list
	init_list(clist);
    //g_object_unref(store);

	//gtk_clist_column_titles_hide((GtkCList *) data);
	//gtk_signal_connect(GTK_OBJECT(clist), "select_row",GTK_SIGNAL_FUNC(selection_made),NULL);
	print_gveri_list(header);
	GVeriList* p = header;
	while(p) {
		add_to_list(clist, p->recentFileName);		
		p=p->next;
	}

	return clist;

		 
 }

int
main (int argc, char **argv)
{
  GtkTextIter mstart;
  GtkTextIter mend;
  int opt;
  while ((opt = getopt(argc, argv, "vV")) != EOF) {
      switch (opt) {
		case 'v':
			verbose_flag  = TRUE;
		break;
	  
	  }	
  }


  gtk_init(&argc, &argv);
  GVeriWindow* window=(GVeriWindow*)malloc(sizeof(GVeriWindow));
  init_gveri_window(&window);
  window->factory = gtk_icon_factory_new();
  gveri_icon_load(window->factory);
  //---end icon
  
  //string=gveri_load_file("AOI/test.v");
  //window->current_doc=gveri_load_file("AOI/test.v");
  
  window->window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_position(GTK_WINDOW(window->window), GTK_WIN_POS_CENTER);
  gtk_window_set_title(GTK_WINDOW(window->window), "GVeri");
  gtk_widget_set_size_request (window->window, 1250, 800);


  window->vbox = gtk_vbox_new(FALSE, 1);
  window->hbox = gtk_hbox_new(FALSE, 1);
  window->hpaned = gtk_hpaned_new ();
  window->vpaned = gtk_vpaned_new ();
  //toolbar = gtk_toolbar_new();
  gtk_container_add(GTK_CONTAINER(window->window), window->vbox);
  
  //menubar and toolbar
  create_menu(window);

  //Notebook
  window->leftNotebook= gtk_notebook_new();
  gtk_notebook_set_tab_pos (GTK_NOTEBOOK (window->leftNotebook), GTK_POS_BOTTOM);
  window->labelTreeView = gtk_label_new("Module");
  window->labelListView = gtk_label_new("File  ");
  window->frameListView = gtk_frame_new (NULL);
  window->scrolled_win_listView = gtk_scrolled_window_new (NULL, NULL);
  //gtk_widget_set_usize( GTK_WIDGET (scrolled_win_listView), -1, 300);
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (window->scrolled_win_listView),
                                      GTK_POLICY_AUTOMATIC,
                                      GTK_POLICY_AUTOMATIC);
  gtk_widget_show(window->scrolled_win_listView);
  // bottom panel
  window->bottomNotebook= gtk_notebook_new();
  gtk_notebook_set_tab_pos (GTK_NOTEBOOK (window->bottomNotebook), GTK_POS_BOTTOM);
  window->labelCmdView = gtk_label_new("Simulation Cmd/Log");
  window->frameCmdView = gtk_frame_new (NULL);
  window->cmdTextView = gtk_text_view_new();
  gtk_widget_add_events(window->cmdTextView, GDK_BUTTON_PRESS_MASK);
  window->scrolled_win_cmdView = gtk_scrolled_window_new (NULL, NULL);
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (window->scrolled_win_cmdView),
                                      GTK_POLICY_AUTOMATIC,
                                      GTK_POLICY_AUTOMATIC);
  gtk_widget_show(window->scrolled_win_cmdView);
  gtk_widget_show(window->cmdTextView);
  gtk_container_add (GTK_CONTAINER (window->scrolled_win_cmdView), GTK_WIDGET (window->cmdTextView)); ///What is added to scroll window
  gtk_container_add (GTK_CONTAINER (window->frameCmdView), window->scrolled_win_cmdView);
  gtk_notebook_append_page (GTK_NOTEBOOK (window->bottomNotebook), window->frameCmdView, window->labelCmdView);
  window->buffer_cmdView = gtk_text_view_get_buffer(GTK_TEXT_VIEW(window->cmdTextView));
  gtk_text_buffer_create_tag(window->buffer_cmdView, "blue_fg", "foreground", "blue", NULL);
  gtk_text_buffer_create_tag(window->buffer_cmdView, "red_fg", "foreground", "red", NULL);
  gtk_text_buffer_set_text(window->buffer_cmdView, info, -1);
  gtk_text_buffer_get_end_iter(window->buffer_cmdView, &mend);
  //Initial the first line
  //gtk_text_buffer_insert(buffer_cmdView, &mend, "\n", 1);
  gtk_text_buffer_create_mark(window->buffer_cmdView, "input-line",&mend , TRUE);
  gtk_text_buffer_insert(window->buffer_cmdView, &mend, ">> ",3);
  gtk_text_buffer_get_end_iter(window->buffer_cmdView, &mend);
  gtk_text_buffer_create_mark(window->buffer_cmdView, "input",&mend , TRUE);
  
  //gtk_text_view_set_editable(GTK_TEXT_VIEW(cmdTextView),1 );	

  //load the clist data
  //gveri_lst_load(&header);
  window->view = create_view_and_model();
  window->listView = create_list_view_and_model();
  if(verbose_flag)
	printf("ALZ :: Here\n");
  gtk_container_add (GTK_CONTAINER (window->scrolled_win_listView), GTK_WIDGET (window->listView)); ///What is added to scroll window
  gtk_container_add (GTK_CONTAINER (window->frameListView), window->scrolled_win_listView);


  window->selectionListView = gtk_tree_view_get_selection(GTK_TREE_VIEW(window->listView));
  window->selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(window->view));

  gtk_widget_show (window->listView);
  gtk_widget_show (window->view);

  window->frame = gtk_frame_new (NULL);
  window->frameInTextView = gtk_frame_new (NULL);
  gtk_container_border_width (GTK_CONTAINER (window->frame), 1);
  gtk_container_border_width (GTK_CONTAINER (window->frameInTextView), 1);
  gtk_widget_show(window->frameInTextView);
  gtk_widget_show(window->frame);
  window->scrolled_win = gtk_scrolled_window_new (NULL, NULL);
  gtk_widget_set_usize( GTK_WIDGET (window->scrolled_win), -1, 300);
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (window->scrolled_win),
                                      GTK_POLICY_AUTOMATIC,
                                      GTK_POLICY_AUTOMATIC);
  gtk_widget_show(window->scrolled_win);
  gtk_container_add (GTK_CONTAINER (window->scrolled_win), GTK_WIDGET (window->view)); ///What is added to scroll window
  gtk_container_add (GTK_CONTAINER (window->frame), window->scrolled_win);
  gtk_notebook_append_page (GTK_NOTEBOOK (window->leftNotebook), window->frame, window->labelTreeView);
  gtk_notebook_append_page (GTK_NOTEBOOK (window->leftNotebook), window->frameListView, window->labelListView);
  gtk_paned_pack1 (GTK_PANED (window->hpaned), window->leftNotebook, TRUE, FALSE);
  gtk_widget_show (window->leftNotebook);


  window->scrolled_win_text = gtk_scrolled_window_new (NULL, NULL);
  gtk_widget_set_usize( GTK_WIDGET (window->scrolled_win_text), -1, 300);
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (window->scrolled_win_text),
                                  GTK_POLICY_NEVER,
                                  GTK_POLICY_AUTOMATIC);
  gtk_widget_show(window->scrolled_win_text);
  /*Code for the textViwe*/
  window->vboxText = gtk_vbox_new(FALSE, 1 );
  window->fileTitle = gtk_label_new(" ");
  window->cmdBuf = gtk_text_buffer_new(NULL);
  window->cmdView =  gtk_text_view_new_with_buffer(window->cmdBuf);
  window->buffer = GTK_SOURCE_BUFFER(gtk_source_buffer_new(NULL)); 
  window->textView = gtk_source_view_new_with_buffer(window->buffer);

  gtk_label_set_single_line_mode(GTK_LABEL(window->fileTitle), TRUE);
  gtk_label_set_justify(GTK_LABEL(window->fileTitle), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment(GTK_MISC(window->fileTitle),  0,0.5);
  gtk_text_view_set_editable(GTK_TEXT_VIEW(window->cmdView), FALSE);
  //window->textView = gtk_text_view_new();
  window->lm = gtk_source_languages_manager_new();
  window->language = gtk_source_languages_manager_get_language_from_mime_type (window->lm,"text/x-verilog-src");
  if(!window->language) {
	//	exit(0);		
		printf("ALZ: NO such language\n");
  }
  gtk_source_buffer_set_language(window->buffer,window->language);
  g_object_set (G_OBJECT (window->buffer), "highlight", TRUE, NULL);
  gtk_widget_add_events(window->textView, GDK_BUTTON_PRESS_MASK);
  gtk_container_add (GTK_CONTAINER (window->scrolled_win_text), GTK_WIDGET (window->textView)); ///What is added to scroll window
  gtk_box_pack_start (GTK_BOX (window->vboxText), window->scrolled_win_text, TRUE, TRUE, 1);
  gtk_box_pack_start (GTK_BOX (window->vboxText), window->fileTitle, FALSE, FALSE, 1);
  gtk_box_pack_start (GTK_BOX (window->vboxText), window->cmdView, FALSE, FALSE, 1);

  gtk_container_add (GTK_CONTAINER (window->frameInTextView), window->vboxText);

  gtk_paned_pack1 (GTK_PANED (window->vpaned), window->frameInTextView, TRUE, FALSE);
  gtk_paned_pack2 (GTK_PANED (window->vpaned), window->bottomNotebook, TRUE, FALSE);
  //window->buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(window->textView));
  //gtk_text_buffer_set_text(window->buffer, window->current_doc->str, -1);
  gtk_text_buffer_create_tag(GTK_TEXT_BUFFER(window->buffer), "gray_bg", "background", "gray", NULL); 
  gtk_text_buffer_create_tag(GTK_TEXT_BUFFER(window->buffer), "yellow_bg", "background", "yellow", NULL); 

  gtk_paned_pack2 (GTK_PANED (window->hpaned), window->vpaned, TRUE, FALSE);
  gtk_box_pack_start(GTK_BOX(window->vbox), window->hpaned, TRUE, TRUE, 1);

  window->statusbar = gtk_statusbar_new();
  gtk_box_pack_start(GTK_BOX(window->vbox), window->statusbar, FALSE, TRUE, 1);

  g_signal_connect(window->selection, "changed", G_CALLBACK(on_changed), window);
  g_signal_connect(window->selectionListView, "changed", G_CALLBACK(selection_made),window);
  //g_signal_connect(view, "clicked", G_CALLBACK(show_file), buffer);//double click
  //g_signal_connect(view, "button-press-event", G_CALLBACK(show_file), buffer);//double click

  g_signal_connect(G_OBJECT(window->cmdTextView), "key-press-event",G_CALLBACK(command_parse), window->buffer_cmdView);
  g_signal_connect(G_OBJECT(window->buffer_cmdView), "mark-set", G_CALLBACK(mark_set_cb), window->cmdTextView);
  g_signal_connect(G_OBJECT(window->textView), "key-press-event",G_CALLBACK(key_pressed), window);
  g_signal_connect(G_OBJECT(window->cmdView), "key-press-event",G_CALLBACK(cmdView_key_pressed), window);
  g_signal_connect (G_OBJECT (window->window), "destroy", G_CALLBACK(gtk_main_quit), NULL);

  gtk_widget_show_all(window->window);

  gtk_main();

  return 0;
}

