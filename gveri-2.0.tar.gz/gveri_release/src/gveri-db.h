#ifndef __GVERI_DB_H__
#define __GVERI_DB_H__
#define NAME_LEN 60
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//The scope contains the module/task/function

typedef enum {MODULE, TASK, FUNCTION,NONE} ScopeType;
struct _gveri_list{
	char* recentFileName;
	char* fileFullPath;
	char* context; //add the context
	struct _gveri_list* next;
	struct _gveri_list* prev;
};
typedef struct _gveri_list GVeriList;
struct _gveri_scope{
	ScopeType scopeType;
	char* fileName;
	char* scopeName;
	char* scopeInstName;
	struct _gveri_scope* parent;

	struct _gveri_scope* next; //next to store the identical nodes.
	struct _gveri_scope* prev; //previous node.
	struct _gveri_scope* child; //If the node has child(sub-module), it keeps in childs

};
typedef struct _gveri_scope GVeriScope;
void init_gveri_scope(GVeriScope** gveriScope);
void get_filename(GVeriScope* root, char* moduleName, char** fileName);
GVeriScope* find_gveri_scope(GVeriScope* root, char* moduleName);

GVeriScope* get_parent(GVeriScope* gveriScope);
GVeriScope* get_child(GVeriScope* gveriScope, int* child_num);
void print_gveri_scope(GVeriScope* root);

void init_gveri_list(GVeriList** gveriList);
void append_gveri_list(GVeriList* root, GVeriList* last);
char* gveri_list_get_full_path(GVeriList* root, char* fileName);
GVeriList* gveri_list_get_test(GVeriList* root, char* fileName);
GVeriList* prev_gveri_list(GVeriList* root, char* currentFileName);
GVeriList* next_gveri_list(GVeriList* root, char* currentFileName);
void print_gveri_list(GVeriList* header);
extern GVeriScope* current_scope;
#endif
