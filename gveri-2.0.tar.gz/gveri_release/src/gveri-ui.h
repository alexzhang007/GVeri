#ifndef __GVERI_UI_H__
#define __GVERI_UI_H__
#include <gtk/gtk.h>
#include <glib/gi18n.h>
#include "gveri-commands.h"

#define GVERI_STOCK_LOADDESIGN  "gveri-loaddesign"
#define GVERI_STOCK_SIMULATION  "gveri-simulation"
#define GVERI_STOCK_WAVEFORM    "gveri-waveform"
#define GVERI_STOCK_SIGNALS     "gveri-signals"
#define GVERI_STOCK_NEW			"gveri-filenew"
#define GVERI_STOCK_OPEN		"gveri-fileopen"
#define GVERI_STOCK_SAVE 		"gveri-filesave"
#define GVERI_STOCK_LOCK		"gveri-filelock"
#define GVERI_STOCK_UNLOCK		"gveri-fileunlock"
#define GVERI_STOCK_PARENT 		"gveri-parent"
#define GVERI_STOCK_CHILD 		"gveri-child"
#define GVERI_STOCK_UP   		"gveri-up"
#define GVERI_STOCK_DOWN   		"gveri-down"
#define GVERI_STOCK_BACKWARD	"gveri-backward"
#define GVERI_STOCK_FORWARD		"gveri-forward"
#define GVERI_STOCK_FINDMODULE	"gveri-findmodule"
#define GVERI_STOCK_FINDFILE	"gveri-findfile"
#define GVERI_STOCK_FINDSTRING	"gveri-findstring"

void gveri_icon_load(GtkIconFactory *factory){
  GtkIconSource *source;
  GtkIconSet *set;

  gchar* id=GVERI_STOCK_PARENT;	
  source = gtk_icon_source_new();
  set = gtk_icon_set_new();
  gtk_icon_factory_add_default( GTK_ICON_FACTORY(factory) );
  gtk_icon_source_set_filename( source, GVERI_DATADIR "icons/parent.png" );
  gtk_icon_set_add_source( set, source );
  gtk_icon_factory_add( GTK_ICON_FACTORY(factory), id, set );

  id=GVERI_STOCK_LOADDESIGN; source = gtk_icon_source_new(); set = gtk_icon_set_new();
  gtk_icon_source_set_filename( source, GVERI_DATADIR "icons/loaddesign.png" );
  gtk_icon_set_add_source( set, source );
  gtk_icon_factory_add( GTK_ICON_FACTORY(factory), id, set );

  id=GVERI_STOCK_SIMULATION; source = gtk_icon_source_new(); set = gtk_icon_set_new();
  gtk_icon_source_set_filename( source, GVERI_DATADIR "icons/simulate.png" );  
  gtk_icon_set_add_source( set, source );
  gtk_icon_factory_add( GTK_ICON_FACTORY(factory), id, set );
	
  id=GVERI_STOCK_WAVEFORM; source = gtk_icon_source_new(); set = gtk_icon_set_new();
  gtk_icon_source_set_filename( source, GVERI_DATADIR "icons/wave.png" );  
  gtk_icon_set_add_source( set, source );
  gtk_icon_factory_add( GTK_ICON_FACTORY(factory), id, set );

  id=GVERI_STOCK_NEW; source = gtk_icon_source_new(); set = gtk_icon_set_new();
  gtk_icon_source_set_filename( source, GVERI_DATADIR "icons/filenew.png" );
  gtk_icon_set_add_source( set, source );
  gtk_icon_factory_add( GTK_ICON_FACTORY(factory), id, set );

  id=GVERI_STOCK_OPEN; source = gtk_icon_source_new(); set = gtk_icon_set_new();
  gtk_icon_source_set_filename( source, GVERI_DATADIR "icons/fileopen.png" );
  gtk_icon_set_add_source( set, source );
  gtk_icon_factory_add( GTK_ICON_FACTORY(factory), id, set );

  id=GVERI_STOCK_SAVE; source = gtk_icon_source_new(); set = gtk_icon_set_new();
  gtk_icon_source_set_filename( source, GVERI_DATADIR "icons/filesave.png" ); 
  gtk_icon_set_add_source( set, source );
  gtk_icon_factory_add( GTK_ICON_FACTORY(factory), id, set );

  id=GVERI_STOCK_LOCK; source = gtk_icon_source_new(); set = gtk_icon_set_new();
  gtk_icon_source_set_filename( source, GVERI_DATADIR "icons/lock.png" ); 
  gtk_icon_set_add_source( set, source );
  gtk_icon_factory_add( GTK_ICON_FACTORY(factory), id, set );

  id=GVERI_STOCK_UNLOCK; source = gtk_icon_source_new(); set = gtk_icon_set_new();
  gtk_icon_source_set_filename( source, GVERI_DATADIR "icons/unlock.png" ); 
  gtk_icon_set_add_source( set, source );
  gtk_icon_factory_add( GTK_ICON_FACTORY(factory), id, set );

  id=GVERI_STOCK_CHILD; source = gtk_icon_source_new(); set = gtk_icon_set_new();
  gtk_icon_source_set_filename( source, GVERI_DATADIR "icons/child.png" );
  gtk_icon_set_add_source( set, source );
  gtk_icon_factory_add( GTK_ICON_FACTORY(factory), id, set );

  id=GVERI_STOCK_UP; source = gtk_icon_source_new(); set = gtk_icon_set_new();
  gtk_icon_source_set_filename( source, GVERI_DATADIR "icons/up.png" );
  gtk_icon_set_add_source( set, source );
  gtk_icon_factory_add( GTK_ICON_FACTORY(factory), id, set );

  id=GVERI_STOCK_DOWN; source = gtk_icon_source_new(); set = gtk_icon_set_new();
  gtk_icon_source_set_filename( source, GVERI_DATADIR "icons/down.png" );
  gtk_icon_set_add_source( set, source );
  gtk_icon_factory_add( GTK_ICON_FACTORY(factory), id, set );

  id=GVERI_STOCK_BACKWARD; source = gtk_icon_source_new(); set = gtk_icon_set_new();
  gtk_icon_source_set_filename( source, GVERI_DATADIR "icons/left.png" );
  gtk_icon_set_add_source( set, source );
  gtk_icon_factory_add( GTK_ICON_FACTORY(factory), id, set );
 
  id=GVERI_STOCK_FORWARD; source = gtk_icon_source_new(); set = gtk_icon_set_new();
  gtk_icon_source_set_filename( source, GVERI_DATADIR "icons/right.png" );
  gtk_icon_set_add_source( set, source );
  gtk_icon_factory_add( GTK_ICON_FACTORY(factory), id, set );

  id=GVERI_STOCK_FINDMODULE; source = gtk_icon_source_new(); set = gtk_icon_set_new();
  gtk_icon_source_set_filename( source, GVERI_DATADIR "icons/findmodule.png" );
  gtk_icon_set_add_source( set, source );
  gtk_icon_factory_add( GTK_ICON_FACTORY(factory), id, set );
  
  id=GVERI_STOCK_FINDFILE; source = gtk_icon_source_new(); set = gtk_icon_set_new();
  gtk_icon_source_set_filename( source, GVERI_DATADIR "icons/findfile.png" ); 
  gtk_icon_set_add_source( set, source );
  gtk_icon_factory_add( GTK_ICON_FACTORY(factory), id, set );

  id=GVERI_STOCK_FINDSTRING; source = gtk_icon_source_new(); set = gtk_icon_set_new();
  gtk_icon_source_set_filename( source, GVERI_DATADIR "icons/findstring.png" ); 
  gtk_icon_set_add_source( set, source );
  gtk_icon_factory_add( GTK_ICON_FACTORY(factory), id, set );

  id=GVERI_STOCK_SIGNALS; source = gtk_icon_source_new(); set = gtk_icon_set_new();
  gtk_icon_source_set_filename( source, GVERI_DATADIR "icons/signals.png" ); 
  gtk_icon_set_add_source( set, source );
  gtk_icon_factory_add( GTK_ICON_FACTORY(factory), id, set );
}
static const GtkActionEntry gveri_always_sensitive_menu_entries[] =
{
	/* Toplevel */
	{ "File", NULL, N_("_File") },
	{ "Edit", NULL, N_("_Edit") },
	{ "View", NULL, N_("_View") },
	{ "Simulate", NULL, N_("_Simulate") },
	{ "Tools", NULL, N_("_Tools") },
	{ "Help", NULL, N_("_Help") },

	/* File menu */
	{ "FileNew",  GVERI_STOCK_NEW,  N_("_New"), 	  "<control>N",  N_("Create a new document"), G_CALLBACK (_gveri_cmd_file_new) },
	{ "FileOpen", GVERI_STOCK_OPEN, N_("_Open..."), "<control>O",	  N_("Open a file"), G_CALLBACK (_gveri_cmd_file_open) },	
	/* Edit menu */
	{ "EditPreferences", GTK_STOCK_PREFERENCES, N_("Pr_eferences"), NULL,  N_("Configure the application"), G_CALLBACK (_gveri_cmd_edit_preferences) },
	/* Help menu */
	{"HelpContents", GTK_STOCK_HELP, N_("Contents"), "F1",	 N_("Open the gedit manual"), G_CALLBACK (_gveri_cmd_help_contents) },
	{ "HelpAbout", GTK_STOCK_ABOUT, NULL, NULL, N_("About this application"), G_CALLBACK (_gveri_cmd_help_about) }
};

static const GtkActionEntry gveri_menu_entries[] =
{
	/* File menu */
	{ "FileSave",   GVERI_STOCK_SAVE,      N_("_Save"), "<control>S", N_("Save the current file"), G_CALLBACK (_gveri_cmd_file_save) },
	{ "FileSaveAs", GTK_STOCK_SAVE_AS, N_("Save _As..."), "<shift><control>S", N_("Save the current file with a different name"), G_CALLBACK (_gveri_cmd_file_save_as) },
	{ "LoadDesign", GVERI_STOCK_LOADDESIGN,              N_("_LoadDesign..."), "<control>L", N_("Load Design"), G_CALLBACK (_gveri_cmd_load_design) },
	{ "Quit", 		NULL,              N_("_Quit"), "<control>L", N_("Quit"), G_CALLBACK (_gveri_cmd_quit) },

	/* Edit menu */
	{ "LockContent", 	GVERI_STOCK_LOCK, N_("_LockContent"), NULL,  N_("LockContent"), G_CALLBACK (_gveri_cmd_lock_content) },
	{ "UnlockContent",  GVERI_STOCK_UNLOCK, N_("_UnlockContent"), "<control>U", N_("UnlockContent"),  G_CALLBACK (_gveri_cmd_unlock_content) },

	/* View menu */
	{ "ViewWaveform",    GVERI_STOCK_WAVEFORM, N_("View _Waveform"), NULL,N_("View Waveform"), 	G_CALLBACK(_gveri_cmd_view_waveform) },
	{ "ViewSignals",     GVERI_STOCK_SIGNALS, N_("View Signals"), NULL,N_("View all signals"), 	G_CALLBACK(_gveri_cmd_view_all_signals) },
	{ "ParentModule",    GVERI_STOCK_PARENT, N_("_Parent Module"), NULL,N_("Parent Module"), 	G_CALLBACK(_gveri_cmd_parent_module) },
	{ "ChildModule",     GVERI_STOCK_CHILD, N_("_Child Module"), NULL,N_("Child Module"), 		G_CALLBACK(_gveri_cmd_child_module) },
	{ "ViewUp",          GVERI_STOCK_UP, N_("Up"), NULL,N_("Up"), 				G_CALLBACK(_gveri_cmd_up) },
	{ "ViewDown",        GVERI_STOCK_DOWN, N_("Down"), NULL,N_("Down"), 				G_CALLBACK(_gveri_cmd_down) },
	{ "BackwardHistory", GVERI_STOCK_BACKWARD, N_("_Backword History"), NULL,N_("Backward History"), 	G_CALLBACK(_gveri_cmd_backward_history) },
	{ "ForwardHistory",  GVERI_STOCK_FORWARD, N_("_Forward History"), NULL,N_("Forward History"), 	G_CALLBACK(_gveri_cmd_forward_history) },

    /* Tool Menu */
	{ "FindModule",    GVERI_STOCK_FINDMODULE, N_("Find Module"), "<control>M",N_("Find Module"), 	G_CALLBACK(_gveri_cmd_find_module) },
	{ "FindFile",      GVERI_STOCK_FINDFILE, N_("Find File"),   "<control>F",  N_("Find a file"), 	G_CALLBACK(_gveri_cmd_find_file) },
	{ "FindString",    GVERI_STOCK_FINDSTRING, N_("Find String"), "<control>S",  N_("Find a String"),	G_CALLBACK(_gveri_cmd_find_string) },

	/* Simulate menu */
	{ "Simulation", GVERI_STOCK_SIMULATION, N_("_Simultion..."), "<control>S", N_("Simulate the Design"), G_CALLBACK (_gveri_cmd_simulation) }
};

#endif

